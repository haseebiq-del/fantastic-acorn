# Focus Trophy

Native Android study timer with daily study history and an opt-in Accessibility Service that returns the user to a block screen when a selected app is opened during an active focus session.

## Build

Open this folder as an Android Gradle project. It targets SDK 35 and requires JDK 17.

## First setup

1. Install the APK/build the project.
2. Open Focus Trophy.
3. Tap **Choose Apps to Block** and select apps.
4. Tap **Enable Focus Protection** and enable Focus Trophy in Android Accessibility settings.
5. Start a study session.

## Important Android limitation

A normal third-party app cannot guarantee an unbreakable system-wide lock or kiosk mode on every Android device. Accessibility-based blocking is best-effort and depends on Android/device behavior. True kiosk/lock-task enforcement generally requires device-owner/managed-device provisioning.

The app does not attempt to bypass Android security or hidden system restrictions.
