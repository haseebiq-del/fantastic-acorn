package com.focustrophy.app

import android.app.Service
import android.content.Intent
import android.os.IBinder

class FocusTimerService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
