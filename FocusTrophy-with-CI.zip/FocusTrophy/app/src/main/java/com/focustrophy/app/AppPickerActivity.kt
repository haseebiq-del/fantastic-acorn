package com.focustrophy.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class AppPickerActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); title="Choose Apps to Block"; val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(20,20,20,20); val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL; val scroll=ScrollView(this); scroll.addView(list); val selected=Store.blocked(this).toMutableSet(); val pm=packageManager; val apps=pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL).distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(pm).toString().lowercase()}; apps.forEach{r-> val pkg=r.activityInfo.packageName; if(pkg==packageName)return@forEach; val cb=CheckBox(this); cb.text=r.loadLabel(pm); cb.textSize=16f; cb.isChecked=selected.contains(pkg); cb.setOnCheckedChangeListener{_,yes->if(yes)selected.add(pkg)else selected.remove(pkg)}; list.addView(cb)}; val save=Button(this); save.text="Save"; save.setOnClickListener{Store.setBlocked(this,selected); finish()}; box.addView(TextView(this).apply{text="Select apps that should be blocked during Focus Mode"; textSize=18f; gravity=Gravity.CENTER; setPadding(0,0,0,15)}); box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); box.addView(save); setContentView(box) }
}
