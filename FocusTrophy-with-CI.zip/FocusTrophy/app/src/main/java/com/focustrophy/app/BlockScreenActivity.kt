package com.focustrophy.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class BlockScreenActivity : Activity() {
    override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(R.layout.activity_block_screen)}
    override fun onBackPressed(){ if(Store.active(this)) return else super.onBackPressed() }
}
