package com.focustrophy.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private const val PREFS = "focus_trophy"
    private const val BLOCKED = "blocked"
    private const val HISTORY = "history"
    private const val END = "end"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun blocked(c: Context): Set<String> = p(c).getStringSet(BLOCKED, emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) { p(c).edit().putStringSet(BLOCKED, s).apply() }
    fun end(c: Context) = p(c).getLong(END, 0L)
    fun active(c: Context) = end(c) > System.currentTimeMillis()
    fun start(c: Context, ms: Long) { p(c).edit().putLong(END, System.currentTimeMillis()+ms).apply() }
    fun stop(c: Context) { p(c).edit().remove(END).apply() }
    fun addStudy(c: Context, minutes: Int) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val old = p(c).getInt("day_$key", 0)
        p(c).edit().putInt("day_$key", old + minutes).apply()
    }
    fun day(c: Context): Int {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return p(c).getInt("day_$key", 0)
    }
    fun all(c: Context): Int {
        val prefs = p(c)
        return prefs.all.filterKeys { it.startsWith("day_") }.values.sumOf { (it as? Int) ?: 0 }
    }
    fun history(c: Context): List<Pair<String,Int>> {
        return p(c).all.filterKeys { it.startsWith("day_") }.mapNotNull {
            (it.key.removePrefix("day_") to ((it.value as? Int) ?: 0))
        }.sortedByDescending { it.first }
    }
}
