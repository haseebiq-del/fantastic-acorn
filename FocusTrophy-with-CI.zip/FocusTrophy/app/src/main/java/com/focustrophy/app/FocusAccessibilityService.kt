package com.focustrophy.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if(event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if(!Store.active(this)) return
        val pkg = event.packageName?.toString() ?: return
        if(pkg == packageName) return
        if(Store.blocked(this).contains(pkg)) {
            val i=Intent(this, BlockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        }
    }
    override fun onInterrupt() {}
}
