package com.focustrophy.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.app.Activity
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var timer: TextView
    private lateinit var progress: ProgressBar
    private var totalMs = 25L * 60_000L
    private var endMs = 0L
    private var tick: Thread? = null
    private var counted = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        timer = findViewById(R.id.timerText); progress = findViewById(R.id.progress)
        findViewById<Button>(R.id.start).setOnClickListener { startFocus() }
        findViewById<Button>(R.id.pause).setOnClickListener { stopFocus() }
        findViewById<Button>(R.id.reset).setOnClickListener { stopFocus(); endMs=0; counted=false; render(totalMs) }
        findViewById<Button>(R.id.min25).setOnClickListener { setMinutes(25) }
        findViewById<Button>(R.id.min45).setOnClickListener { setMinutes(45) }
        findViewById<Button>(R.id.min60).setOnClickListener { setMinutes(60) }
        findViewById<Button>(R.id.setCustom).setOnClickListener { setCustom() }
        findViewById<Button>(R.id.chooseApps).setOnClickListener { startActivity(Intent(this, AppPickerActivity::class.java)) }
        findViewById<Button>(R.id.accessibility).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        updateStats(); render(totalMs)
    }
    private fun setMinutes(m:Int){ stopFocus(); totalMs=m*60_000L; render(totalMs) }
    private fun setCustom(){ val n=findViewById<EditText>(R.id.customMinutes).text.toString().toLongOrNull(); if(n==null||n<1||n>600){Toast.makeText(this,"Enter 1–600 minutes",Toast.LENGTH_SHORT).show()}else setMinutes(n.toInt()) }
    private fun startFocus(){ if(Store.blocked(this).isEmpty()){Toast.makeText(this,"Choose at least one app to block.",Toast.LENGTH_LONG).show(); return}; endMs=System.currentTimeMillis()+totalMs; counted=false; Store.start(this,totalMs); renderLoop() }
    private fun stopFocus(){ Store.stop(this); tick?.interrupt(); endMs=0 }
    private fun renderLoop(){ tick?.interrupt(); tick=Thread { while(!isFinishing() && Store.active(this)){ val left=(Store.end(this)-System.currentTimeMillis()).coerceAtLeast(0); runOnUiThread{render(left)}; Thread.sleep(500); if(left<=0) break }; runOnUiThread{finishSession()} }; tick?.start() }
    private fun render(ms:Long){ val s=TimeUnit.MILLISECONDS.toSeconds(ms); val mm=s/60; val ss=s%60; timer.text=String.format("%02d:%02d",mm,ss); progress.progress=((ms.toDouble()/totalMs.coerceAtLeast(1))*100).toInt().coerceIn(0,100) }
    private fun finishSession(){ if(counted)return; counted=true; val mins=(totalMs/60_000L).toInt(); Store.addStudy(this,mins); Store.stop(this); Toast.makeText(this,"🏆 Study session complete!",Toast.LENGTH_LONG).show(); updateStats(); render(0) }
    private fun updateStats(){ findViewById<TextView>(R.id.today).text="Today: ${Store.day(this)/60}h ${Store.day(this)%60}m"; findViewById<TextView>(R.id.allTime).text="All time: ${Store.all(this)/60}h ${Store.all(this)%60}m"; findViewById<TextView>(R.id.history).text=Store.history(this).joinToString("\n") { "🏆 ${it.first}   ${it.second/60}h ${it.second%60}m" }.ifBlank { "No study sessions yet." } }
}
