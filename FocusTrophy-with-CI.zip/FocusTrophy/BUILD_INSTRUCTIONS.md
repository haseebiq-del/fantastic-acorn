# Focus Trophy — Android Gradle Project

This is a native Android Gradle project.

## Build with Android Studio

1. Extract this ZIP.
2. Open the `FocusTrophy` folder in Android Studio.
3. Use JDK 17 for the Gradle/Android build.
4. Allow Gradle to sync and install any requested SDK components.
5. Select **Build > Build APK(s)**.
6. The debug APK will normally be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Project requirements

- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Compile/target SDK: 35
- Minimum SDK: 26
- Java/Kotlin toolchain: 17

## Focus protection

The app uses Android's Accessibility Service to detect selected apps while a focus
session is active. The user must explicitly enable the service in Android Settings.

A normal Android app cannot guarantee an unbreakable lock against leaving the app
on every device. True kiosk-style enforcement requires managed/device-owner setup.
